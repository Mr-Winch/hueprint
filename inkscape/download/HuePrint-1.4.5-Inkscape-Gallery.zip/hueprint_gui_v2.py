"""HuePrint GTK interface: responsive metadata, collision-safe geometry, palettes."""
import colorsys, ctypes, json, math, os, random, sys, xml.etree.ElementTree as ET
from ctypes import wintypes
import cairo
from pathlib import Path
import gi
gi.require_version("Gtk","3.0"); gi.require_version("Gdk","3.0"); gi.require_version("GdkPixbuf","2.0"); gi.require_version("Pango","1.0")
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk, Pango
from hueprint_palette import generate_palette, hex_to_hls, hls_to_hex, palette_from_text, palette_storage_path, palette_to_gpl, sanitize_hex, translate_palette_geometry
from hueprint_recipes import RECIPES, generate_recipe, hex_to_oklch, randomize_recipe
from hueprint_recipe_metadata import CATEGORY_LABELS, CATEGORY_ORDER, RECIPE_IDS_BY_CATEGORY, RECIPE_METADATA, RECIPE_METADATA_BY_ID

HARMONIES = [
 ("monochromatic","Monochromatic","One hue with a balanced light-to-dark range."),
 ("analogous","Analogous","Neighboring hues for a calm, cohesive palette."),
 ("complementary","Complementary","Opposing hues paired across the wheel."),
 ("split_complementary","Split Complementary","An anchor plus the two neighbors of its opposite."),
 ("triadic","Triadic","Three hue families separated by 120 degrees."),
 ("square","Square","Four hue families separated by 90 degrees."),
 ("rectangle_tetradic","Rectangle / Tetradic","Two complementary pairs in a rectangular harmony."),
 ("polygon","Polygon / Equidistant","Evenly spaces every swatch around the wheel."),
 ("tint","Tint","Mixes the active color toward white."),
 ("shade","Shade","Mixes the active color toward black."),
 ("tone","Tone","Reduces saturation while preserving lightness."),
]
def _rgba(value):
    color=Gdk.RGBA(); color.parse(sanitize_hex(value)); return color
def _palette_path():
    path=palette_storage_path(); path.parent.mkdir(parents=True,exist_ok=True); return path
def _legacy_palette_path():
    return Path(os.environ.get("APPDATA",Path.home()/".config"))/"inkscape"/"hueprint-palettes.json"
def _saved_palettes_path():
    return _palette_path().with_name("saved-palette-library.json")
def _legacy_named_palettes_path():
    return _palette_path().with_name("named-palettes.json")
def _inkscape_prefers_dark():
    try:
        preferences=Path(os.environ.get("APPDATA",Path.home()/".config"))/"inkscape"/"preferences.xml"
        theme=ET.parse(preferences).getroot().find(".//*[@id='theme']")
        if theme is not None:return theme.get("preferDarkTheme",theme.get("darkTheme","0"))=="1"
    except (OSError,ET.ParseError):pass
    settings=Gtk.Settings.get_default(); return bool(settings and settings.get_property("gtk-application-prefer-dark-theme"))
def _windows_handle(value):
    value=int(value or 0); return value&0xffffffff if value>>32==0xffffffff else value

class NativeScreenSampler:
    VK_LBUTTON=0x01; VK_ESCAPE=0x1B; WH_MOUSE_LL=14; WM_LBUTTONDOWN=0x0201; WM_LBUTTONUP=0x0202
    def __init__(self):
        if not sys.platform.startswith("win"):raise OSError("The native screen picker currently requires Windows")
        self.user32=ctypes.WinDLL("user32",use_last_error=True); self.gdi32=ctypes.WinDLL("gdi32",use_last_error=True); self.kernel32=ctypes.WinDLL("kernel32",use_last_error=True)
        self.user32.GetCursorPos.argtypes=[ctypes.POINTER(wintypes.POINT)]; self.user32.GetCursorPos.restype=wintypes.BOOL
        self.user32.GetAsyncKeyState.argtypes=[ctypes.c_int]; self.user32.GetAsyncKeyState.restype=ctypes.c_short
        self.user32.GetDC.argtypes=[wintypes.HWND]; self.user32.GetDC.restype=wintypes.HDC
        self.user32.ReleaseDC.argtypes=[wintypes.HWND,wintypes.HDC]; self.user32.ReleaseDC.restype=ctypes.c_int
        self.gdi32.GetPixel.argtypes=[wintypes.HDC,ctypes.c_int,ctypes.c_int]; self.gdi32.GetPixel.restype=wintypes.DWORD
        self.left=self.user32.GetSystemMetrics(76); self.top=self.user32.GetSystemMetrics(77); self.width=self.user32.GetSystemMetrics(78); self.height=self.user32.GetSystemMetrics(79)
        if self.width<=0 or self.height<=0:raise OSError("Windows screen access is unavailable")
        self.armed=False; self.clicked_point=None; self.swallow_release=False; self.hook=None
        class MouseInfo(ctypes.Structure):
            _fields_=[("pt",wintypes.POINT),("mouseData",wintypes.DWORD),("flags",wintypes.DWORD),("time",wintypes.DWORD),("extra",ctypes.c_size_t)]
        self.mouse_info_type=MouseInfo; self.mouse_proc_type=ctypes.WINFUNCTYPE(ctypes.c_ssize_t,ctypes.c_int,wintypes.WPARAM,wintypes.LPARAM); self.mouse_proc=self.mouse_proc_type(self._mouse_event)
        self.user32.SetWindowsHookExW.argtypes=[ctypes.c_int,self.mouse_proc_type,wintypes.HANDLE,wintypes.DWORD]; self.user32.SetWindowsHookExW.restype=wintypes.HANDLE
        self.user32.CallNextHookEx.argtypes=[wintypes.HANDLE,ctypes.c_int,wintypes.WPARAM,wintypes.LPARAM]; self.user32.CallNextHookEx.restype=ctypes.c_ssize_t
        self.user32.UnhookWindowsHookEx.argtypes=[wintypes.HANDLE]; self.user32.UnhookWindowsHookEx.restype=wintypes.BOOL
        self.kernel32.GetModuleHandleW.argtypes=[wintypes.LPCWSTR]; self.kernel32.GetModuleHandleW.restype=wintypes.HANDLE
        self.hook=self.user32.SetWindowsHookExW(self.WH_MOUSE_LL,self.mouse_proc,self.kernel32.GetModuleHandleW(None),0)
        if not self.hook:raise ctypes.WinError(ctypes.get_last_error())
    def _mouse_event(self,code,message,data):
        if code>=0:
            message=int(message)
            if message==self.WM_LBUTTONDOWN and self.armed:
                info=ctypes.cast(data,ctypes.POINTER(self.mouse_info_type)).contents; self.clicked_point=(info.pt.x,info.pt.y); self.armed=False; self.swallow_release=True; return 1
            if message==self.WM_LBUTTONUP and self.swallow_release:self.swallow_release=False; return 1
        return self.user32.CallNextHookEx(self.hook,code,message,data)
    def arm(self):self.armed=True
    def take_click(self):
        if self.clicked_point is None or self.swallow_release:return None
        point=self.clicked_point; self.clicked_point=None; return point
    def position(self):
        point=wintypes.POINT()
        if not self.user32.GetCursorPos(ctypes.byref(point)):raise ctypes.WinError(ctypes.get_last_error())
        return point.x,point.y
    def key_state(self,key):return int(self.user32.GetAsyncKeyState(key))&0xffff
    def pressed(self,key):return bool(self.key_state(key)&0x8000)
    def color_at(self,x,y):
        dc=_windows_handle(self.user32.GetDC(None))
        if not dc:raise ctypes.WinError(ctypes.get_last_error())
        try:
            value=int(self.gdi32.GetPixel(dc,int(x),int(y)))
            if value==0xffffffff:raise ctypes.WinError(ctypes.get_last_error())
            return "#%02X%02X%02X"%(value&0xff,(value>>8)&0xff,(value>>16)&0xff)
        finally:self.user32.ReleaseDC(None,dc)
    def close(self):
        self.armed=False; self.swallow_release=False
        if self.hook:self.user32.UnhookWindowsHookEx(self.hook); self.hook=None
def _clamp(value,low=0,high=1): return min(high,max(low,value))
def _distance(a,b): return math.hypot(a[0]-b[0],a[1]-b[1])

SVG_ICONS = {
 "dropper":"<path d='M19.4 3.6a2 2 0 0 1 0 2.8l-9.9 9.9-3.8.7.7-3.8 9.9-9.9a2 2 0 0 1 2.8 0zM13.5 6.5l4 4M5.7 17l-2.2 2.2V21h1.8l2.2-2.2' fill='none'/>",
 "copy":"<rect x='8' y='8' width='11' height='11' rx='2' fill='none'/><path d='M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2' fill='none'/>",
 "check":"<path d='M5 12.5l4.2 4.2L19 7' fill='none'/>",
 "add":"<path d='M12 5v14M5 12h14' fill='none'/>",
 "minus":"<path d='M5 12h14' fill='none'/>",
 "random":"<path d='M4 7h3c4 0 5 10 9 10h4M16 13l4 4-4 4M4 17h3c1.8 0 3-2 4-4M13 7h7M16 3l4 4-4 4' fill='none'/>",
 "palette":"<path d='M12 3a9 9 0 1 0 0 18h1.2a1.8 1.8 0 0 0 0-3.6h-1a1.8 1.8 0 0 1 0-3.6H16A5 5 0 0 0 21 9c0-3.3-4-6-9-6z' fill='none'/><circle cx='8' cy='8' r='1'/><circle cx='12' cy='6.5' r='1'/><circle cx='16' cy='8.5' r='1'/>",
 "import":"<path d='M12 3v12M7 10l5 5 5-5M4 20h16' fill='none'/>",
 "use":"<rect x='4' y='15' width='4' height='4' rx='1' fill='none'/><rect x='10' y='15' width='4' height='4' rx='1' fill='none'/><rect x='16' y='15' width='4' height='4' rx='1' fill='none'/><path d='M12 13V4M8 8l4-4 4 4' fill='none'/>",
 "export":"<path d='M12 17V5M7 10l5-5 5 5M4 20h16' fill='none'/>",
 "save":"<path d='M5 4h12l3 3v13H4V4zM8 4v6h8V4M8 20v-6h8v6' fill='none'/>",
 "trash":"<path d='M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13M10 10v7M14 10v7' fill='none'/>",
 "left":"<path d='M16 4.5L6.5 12 16 19.5z' fill='#000000' stroke='none'/>",
 "right":"<path d='M8 4.5l9.5 7.5L8 19.5z' fill='#000000' stroke='none'/>",
 "close":"<path d='M6 6l12 12M18 6L6 18' fill='none'/>",
 "moon":"<path d='M20 15.5A8.5 8.5 0 0 1 8.5 4 8.5 8.5 0 1 0 20 15.5z' fill='none'/>",
 "sun":"<circle cx='12' cy='12' r='4' fill='none'/><path d='M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4' fill='none'/>",
}
def _svg_image(name,size=17,stroke=None):
    if stroke is None:
        settings=Gtk.Settings.get_default(); dark=bool(settings and settings.get_property("gtk-application-prefer-dark-theme")); stroke="#D7E9FF" if dark else "#20242B"
    body=SVG_ICONS[name]; svg=f"<svg xmlns='http://www.w3.org/2000/svg' width='{size}' height='{size}' viewBox='0 0 24 24'><g stroke='{stroke}' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'>{body}</g></svg>"
    loader=GdkPixbuf.PixbufLoader.new_with_type("svg"); loader.set_size(size,size); loader.write(svg.encode("utf-8")); loader.close()
    return Gtk.Image.new_from_pixbuf(loader.get_pixbuf())
def _set_icon(button,name,size=17,stroke=None):
    button.hueprint_icon=name; button.hueprint_icon_size=size; button.hueprint_icon_stroke=stroke; button.set_image(_svg_image(name,size,stroke)); button.set_always_show_image(True)

class DescribedChooser(Gtk.Button):
    def __init__(self,items,columns=1):
        super().__init__(); self.items={item[0]:item for item in items}; self.active_id=None; self.callbacks=[]
        self.label=Gtk.Label(); self.add(self.label); popover=Gtk.Popover.new(self); scroll=Gtk.ScrolledWindow(); scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC); rows=math.ceil(len(items)/columns); scroll.set_min_content_height(min(420,rows*40+18)); scroll.set_max_content_height(420); scroll.set_min_content_width(270 if columns==1 else 520); scroll.set_propagate_natural_height(True)
        grid=Gtk.Grid(); grid.set_row_spacing(3); grid.set_column_spacing(3); grid.set_border_width(6)
        for index,(item_id,label,description) in enumerate(items):
            button=Gtk.Button(label=label); button.set_relief(Gtk.ReliefStyle.NONE); button.set_tooltip_text(description); button.connect("clicked",self.select,item_id); grid.attach(button,index%columns,index//columns,1,1)
        scroll.add(grid); popover.add(scroll); self.popover=popover; self.connect("clicked",self.open_popover); scroll.show_all()
    def get_popover(self):return self.popover
    def open_popover(self,*_args):
        if self.popover.get_visible():self.popover.popdown()
        else:self.popover.show_all(); self.popover.popup()
    def select(self,_button,item_id): self.set_active_id(item_id); self.get_popover().popdown()
    def set_active_id(self,item_id):
        if item_id not in self.items:return False
        changed=item_id!=self.active_id; self.active_id=item_id; self.label.set_text(self.items[item_id][1])
        if changed:
            for callback in self.callbacks:callback(self)
        return True
    def get_active_id(self):return self.active_id
    def connect_changed(self,callback):self.callbacks.append(callback)
class HarmonyBrowser(Gtk.Button):
    PREVIEW_COUNTS = {"monochromatic":5,"analogous":5,"complementary":2,"split_complementary":3,"triadic":3,"square":4,"rectangle_tetradic":4,"polygon":5,"tint":5,"shade":5,"tone":5}
    def __init__(self,owner):
        super().__init__(); self.owner=owner; self.items={item[0]:item for item in HARMONIES}; self.active_id=None; self.callbacks=[]; self.buttons={}; self.indicators={}; self.previews={}; self.preview_cache={}; self.syncing=False
        self.label=Gtk.Label(); self.add(self.label); popover=Gtk.Popover.new(self); outer=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=8); outer.set_border_width(10)
        support=Gtk.Label(label="Choose a geometric relationship for colors generated from the active color."); support.set_xalign(0); outer.pack_start(support,False,False,0)
        scroll=Gtk.ScrolledWindow(); scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC); scroll.set_min_content_width(570); scroll.set_max_content_width(590); scroll.set_min_content_height(430); scroll.set_max_content_height(500); scroll.set_propagate_natural_width(True)
        grid=Gtk.FlowBox(); grid.set_selection_mode(Gtk.SelectionMode.NONE); grid.set_column_spacing(6); grid.set_row_spacing(6); grid.set_min_children_per_line(2); grid.set_max_children_per_line(2); grid.set_homogeneous(True)
        for item in HARMONIES:grid.add(self.make_card(item))
        scroll.add(grid); outer.pack_start(scroll,True,True,0); popover.add(outer); self.popover=popover; self.connect("clicked",self.open_popover); outer.show_all(); self.set_active_id("analogous"); self.refresh_previews()
    def get_popover(self):return self.popover
    def open_popover(self,*_args):
        if self.popover.get_visible():self.popover.popdown()
        else:self.refresh_previews(); self.popover.show_all(); self.popover.popup()
    def make_card(self,item):
        item_id,label,description=item; button=Gtk.ToggleButton(); button.set_relief(Gtk.ReliefStyle.NORMAL); button.set_hexpand(True); button.set_size_request(270,96); button.connect("clicked",self.select,item_id); button.set_tooltip_text(description)
        box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=5); preview=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=1); preview.set_homogeneous(True); box.pack_start(preview,False,False,0); self.previews[item_id]=preview
        heading=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=4); name=Gtk.Label(); name.set_markup(f"<span weight='bold'>{GLib.markup_escape_text(label)}</span>"); name.set_xalign(0); heading.pack_start(name,True,True,0); indicator=Gtk.Label(label="✓"); heading.pack_end(indicator,False,False,0); box.pack_start(heading,False,False,0); self.indicators[item_id]=indicator
        detail=Gtk.Label(label=description); detail.set_xalign(0); detail.set_line_wrap(True); detail.set_max_width_chars(42); box.pack_start(detail,False,False,0); button.add(box); self.buttons[item_id]=button; return button
    def preview_colors(self,item_id):
        key=(self.owner.color,item_id)
        if key not in self.preview_cache:
            self.preview_cache[key]=generate_palette(self.owner.color,item_id,self.PREVIEW_COUNTS[item_id])
            if len(self.preview_cache)>96:self.preview_cache={key:self.preview_cache[key]}
        return self.preview_cache[key]
    def refresh_previews(self):
        for item_id,preview in self.previews.items():
            colors=self.preview_colors(item_id); children=preview.get_children()
            if len(children)!=len(colors):
                for child in children:preview.remove(child)
                for color in colors:
                    area=Gtk.DrawingArea(); area.set_size_request(12,18); area.hueprint_color=color; area.connect("draw",self.draw_preview); preview.pack_start(area,True,True,0)
            else:
                for area,color in zip(children,colors):area.hueprint_color=color; area.queue_draw()
        self.get_popover().get_child().show_all()
        for item_id,indicator in self.indicators.items():indicator.set_visible(item_id==self.active_id)
    @staticmethod
    def draw_preview(area,cr):
        color=Gdk.RGBA(); color.parse(area.hueprint_color); cr.set_source_rgba(color.red,color.green,color.blue,1); cr.rectangle(0,0,area.get_allocated_width(),area.get_allocated_height()); cr.fill(); return False
    def select(self,_button,item_id):
        if self.syncing:return
        self.set_active_id(item_id); self.get_popover().popdown()
    def set_active_id(self,item_id):
        if item_id not in self.items:return False
        changed=item_id!=self.active_id; self.active_id=item_id; self.label.set_text(self.items[item_id][1]); self.syncing=True
        try:
            for option_id,button in self.buttons.items():button.set_active(option_id==item_id); self.indicators[option_id].set_visible(option_id==item_id)
        finally:self.syncing=False
        if changed:
            for callback in self.callbacks:callback(self)
        return True
    def get_active_id(self):return self.active_id
    def connect_changed(self,callback):self.callbacks.append(callback)
class RecipeBrowser(Gtk.Button):
    FILTERS = ("all", "tonal", "accent", "spectrum", "contrast", "systems", "vibrant", "harmony", "darkLuminous", "temperature", "background", "daring", "semantic")
    def __init__(self,owner):
        super().__init__(); self.owner=owner; self.active_id=None; self.callbacks=[]; self.buttons={}; self.indicators={}; self.previews={}; self.preview_cache={}; self.sections={}; self.syncing=False
        self.label=Gtk.Label(); self.add(self.label); popover=Gtk.Popover.new(self); outer=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=8); outer.set_border_width(10)
        support=Gtk.Label(label="Choose how HuePrint develops colors from your base color."); support.set_xalign(0); outer.pack_start(support,False,False,0)
        filters=Gtk.FlowBox(); filters.set_selection_mode(Gtk.SelectionMode.NONE); filters.set_column_spacing(4); filters.set_row_spacing(4); filters.set_min_children_per_line(4); filters.set_max_children_per_line(6); filters.set_homogeneous(False); group=None; self.filter_buttons={}
        for filter_id in self.FILTERS:
            button=Gtk.RadioButton.new_with_label_from_widget(group,CATEGORY_LABELS.get(filter_id,"All")); group=group or button; button.set_mode(False); button.connect("toggled",self.filter_changed,filter_id); filters.add(button); self.filter_buttons[filter_id]=button
        self.filter_buttons["all"].set_active(True); random_button=Gtk.Button(label="Randomize"); random_button.set_tooltip_text("Generate a reproducible variation from a recipe in the active category"); random_button.connect("clicked",self.random_palette); random_button.set_margin_start(10); filters.add(random_button); outer.pack_start(filters,False,False,0)
        scroll=Gtk.ScrolledWindow(); scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC); scroll.set_min_content_width(740); scroll.set_max_content_width(760); scroll.set_propagate_natural_width(True); scroll.set_min_content_height(500); scroll.set_max_content_height(560)
        content=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=10); content.set_border_width(2)
        for category in CATEGORY_ORDER[1:]:
            section=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=4); heading=Gtk.Label(); heading.set_markup(f"<span size='large' weight='bold'>{GLib.markup_escape_text(CATEGORY_LABELS[category])}</span>"); heading.set_xalign(0); section.pack_start(heading,False,False,0)
            grid=Gtk.FlowBox(); grid.set_selection_mode(Gtk.SelectionMode.NONE); grid.set_column_spacing(6); grid.set_row_spacing(6); grid.set_min_children_per_line(1); grid.set_max_children_per_line(3); grid.set_homogeneous(True)
            for recipe_id in RECIPE_IDS_BY_CATEGORY[category]:grid.add(self.make_card(recipe_id))
            section.pack_start(grid,False,False,0); content.pack_start(section,False,False,0); self.sections[category]=section
        scroll.add(content); outer.pack_start(scroll,True,True,0); popover.add(outer); self.popover=popover; self.connect("clicked",self.open_popover); outer.show_all(); self.set_active_id("none"); self.refresh_previews()
    def get_popover(self):return self.popover
    def open_popover(self,*_args):
        if self.popover.get_visible():self.popover.popdown()
        else:self.popover.show_all(); self.apply_filter(); self.popover.popup()
    def make_card(self,recipe_id,compact=False):
        meta=RECIPE_METADATA_BY_ID[recipe_id]; button=Gtk.ToggleButton(); button.set_relief(Gtk.ReliefStyle.NORMAL); button.set_hexpand(True); button.set_size_request(220,82 if compact else 142); button.connect("clicked",self.select,recipe_id)
        character=GLib.markup_escape_text(meta.character); description=GLib.markup_escape_text(meta.description); button.set_tooltip_markup(f"<span line_height='0.95'><span size='large' weight='bold'>{character}</span>\n<span size='small'>{description}</span></span>")
        accessible=button.get_accessible()
        if hasattr(accessible,"set_name"):accessible.set_name(meta.display_name)
        if hasattr(accessible,"set_description"):accessible.set_description(f"Preview of the {meta.display_name} palette generated from the current base color. {meta.character} {meta.description}")
        box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=4); preview=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=1); preview.set_homogeneous(True); box.pack_start(preview,False,False,0); self.previews[recipe_id]=preview
        heading=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=4); name=Gtk.Label(); name.set_markup(f"<span weight='bold'>{GLib.markup_escape_text(meta.display_name)}</span>"); name.set_xalign(0); heading.pack_start(name,True,True,0); indicator=Gtk.Label(label="✓"); indicator.set_tooltip_text("Selected recipe"); heading.pack_end(indicator,False,False,0); box.pack_start(heading,False,False,0); self.indicators[recipe_id]=indicator
        if not compact:
            tone=Gtk.Label(); tone.set_markup(f"<span line_height='0.95'><span size='small' weight='bold'>{character}</span></span>"); tone.set_xalign(0); tone.set_line_wrap(True); tone.set_max_width_chars(34); box.pack_start(tone,False,False,0)
            detail=Gtk.Label(); detail.set_markup(f"<span line_height='0.95'><span size='small'>{description}</span></span>"); detail.set_xalign(0); detail.set_line_wrap(True); detail.set_max_width_chars(34); box.pack_start(detail,False,False,0)
        button.add(box); self.buttons[recipe_id]=button; return button
    def preview_colors(self,recipe_id):
        key=(self.owner.color,recipe_id)
        if key not in self.preview_cache:
            self.preview_cache[key]=[self.owner.color] if recipe_id=="none" else generate_recipe(self.owner.color,recipe_id)
            if len(self.preview_cache)>160:self.preview_cache={key:self.preview_cache[key]}
        return self.preview_cache[key]
    def refresh_previews(self):
        for recipe_id,preview in self.previews.items():
            colors=self.preview_colors(recipe_id); children=preview.get_children()
            if len(children)!=len(colors):
                for child in children:preview.remove(child)
                for color in colors:
                    area=Gtk.DrawingArea(); area.set_size_request(12,18); area.hueprint_color=color; area.connect("draw",self.draw_preview); preview.pack_start(area,True,True,0)
            else:
                for area,color in zip(children,colors):area.hueprint_color=color; area.queue_draw()
        self.get_popover().get_child().show_all(); self.apply_filter()
        for item_id,indicator in self.indicators.items():indicator.set_visible(item_id==self.active_id)
    @staticmethod
    def draw_preview(area,cr):
        color=Gdk.RGBA(); color.parse(area.hueprint_color); cr.set_source_rgba(color.red,color.green,color.blue,1); cr.rectangle(0,0,area.get_allocated_width(),area.get_allocated_height()); cr.fill(); return False
    def select(self,_button,recipe_id):
        if self.syncing:return
        self.owner.clear_random_palette(); self.owner.clear_custom_palette()
        self.set_active_id(recipe_id); self.get_popover().popdown()
    def set_active_id(self,recipe_id):
        if recipe_id not in RECIPE_METADATA_BY_ID:return False
        changed=recipe_id!=self.active_id; self.active_id=recipe_id; self.label.set_text("Choose recipe" if recipe_id=="none" else RECIPE_METADATA_BY_ID[recipe_id].display_name); self.syncing=True
        try:
            for item_id,button in self.buttons.items():button.set_active(item_id==recipe_id); self.indicators[item_id].set_visible(item_id==recipe_id)
        finally:self.syncing=False
        if changed:
            for callback in self.callbacks:callback(self)
        return True
    def get_active_id(self):return self.active_id
    def connect_changed(self,callback):self.callbacks.append(callback)
    def filter_changed(self,button,filter_id):
        if button.get_active():self.current_filter=filter_id; self.apply_filter()
    def random_palette(self,*_args):
        self.owner.randomize_palette(getattr(self,"current_filter","all")); self.get_popover().popdown()
    def apply_filter(self):
        current=getattr(self,"current_filter","all")
        for category,section in self.sections.items():section.set_visible(current=="all" or current==category)
class SavedPaletteBrowser(Gtk.Button):
    def __init__(self,owner):
        super().__init__(); self.owner=owner; self.active_index=None; self.buttons={}; self.indicators={}; self.syncing=False; self.label=Gtk.Label(label="Choose saved palette"); self.add(self.label); self.popover=Gtk.Popover.new(self); self.popover.set_position(Gtk.PositionType.BOTTOM)
        outer=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=8); outer.set_border_width(10); support=Gtk.Label(label="Choose a saved palette to load into Current Palette."); support.set_xalign(0); outer.pack_start(support,False,False,0)
        scroll=Gtk.ScrolledWindow(); scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC); scroll.set_min_content_width(740); scroll.set_max_content_width(760); scroll.set_min_content_height(500); scroll.set_max_content_height(560); scroll.set_propagate_natural_width(True)
        self.grid=Gtk.FlowBox(); self.grid.set_selection_mode(Gtk.SelectionMode.NONE); self.grid.set_column_spacing(6); self.grid.set_row_spacing(6); self.grid.set_min_children_per_line(1); self.grid.set_max_children_per_line(3); self.grid.set_homogeneous(True); scroll.add(self.grid); outer.pack_start(scroll,True,True,0); self.popover.add(outer); self.connect("clicked",self.open_popover); self.refresh_palettes(); outer.show_all(); self.update_selection()
    def open_popover(self,*_args):
        if self.popover.get_visible():self.popover.popdown()
        else:self.refresh_palettes(); self.popover.show_all(); self.update_selection(); self.popover.set_position(Gtk.PositionType.BOTTOM); self.popover.popup()
    def refresh_palettes(self):
        for child in self.grid.get_children():self.grid.remove(child)
        self.owner.icon_buttons=[button for button in self.owner.icon_buttons if not getattr(button,"hueprint_saved_palette_action",False)]; self.buttons={}; self.indicators={}
        if self.active_index is not None and self.active_index>=len(self.owner.saved_palettes):self.active_index=None
        if not self.owner.saved_palettes:
            empty=Gtk.Label(label="No saved palettes yet. Save the Saved Swatches to create one."); empty.set_margin_top(24); empty.set_margin_bottom(24); self.grid.add(empty)
        for index,palette in enumerate(self.owner.saved_palettes):self.grid.add(self.make_card(index,palette))
        self.grid.show_all(); self.update_selection()
    def make_card(self,index,palette):
        name=palette["name"]; colors=palette["colors"]; count=len(colors); escaped_name=GLib.markup_escape_text(name); wrapper=Gtk.Overlay(); wrapper.set_hexpand(True); wrapper.set_size_request(220,142)
        button=Gtk.ToggleButton(); button.set_relief(Gtk.ReliefStyle.NORMAL); button.set_hexpand(True); button.set_size_request(220,142); button.connect("clicked",self.select,index); button.set_tooltip_markup(f"<span line_height='0.95'><span size='large' weight='bold'>{escaped_name}</span>\n<span size='small'>{count} saved colors. Load into Current Palette.</span></span>")
        box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=4); preview=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=1); preview.set_homogeneous(True)
        for color in colors[:16]:
            area=Gtk.DrawingArea(); area.set_size_request(10,18); area.hueprint_color=color; area.connect("draw",HarmonyBrowser.draw_preview); preview.pack_start(area,True,True,0)
        box.pack_start(preview,False,False,0); heading=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=4); heading.set_margin_end(25); label=Gtk.Label(); label.set_markup(f"<span weight='bold'>{escaped_name}</span>"); label.set_xalign(0); label.set_max_width_chars(24); label.set_ellipsize(Pango.EllipsizeMode.END); heading.pack_start(label,True,True,0); indicator=Gtk.Label(label="✓"); indicator.set_tooltip_text("Selected saved palette"); heading.pack_end(indicator,False,False,0); box.pack_start(heading,False,False,0)
        character=Gtk.Label(); character.set_markup(f"<span line_height='0.95'><span size='small' weight='bold'>{count} saved {'color' if count==1 else 'colors'}</span></span>"); character.set_xalign(0); box.pack_start(character,False,False,0)
        detail=Gtk.Label(); detail.set_markup("<span line_height='0.95'><span size='small'>Load into Current Palette for editing or application.</span></span>"); detail.set_xalign(0); detail.set_line_wrap(True); detail.set_max_width_chars(34); box.pack_start(detail,False,False,0); button.add(box); wrapper.add(button); self.buttons[index]=button; self.indicators[index]=indicator
        delete=self.owner._icon_button("trash",f"Delete saved palette {name}",lambda *_args,i=index:self.delete_palette(i),24); delete.hueprint_saved_palette_action=True; delete.set_halign(Gtk.Align.END); delete.set_valign(Gtk.Align.START); delete.set_margin_top(27); delete.set_margin_end(5); wrapper.add_overlay(delete); return wrapper
    def select(self,_button,index):
        if self.syncing:return
        self.popover.popdown(); self.owner.use_saved_palette_collection(index)
    def delete_palette(self,index):
        self.popover.popdown(); self.owner.delete_saved_palette(index)
    def update_selection(self):
        self.syncing=True
        try:
            for index,button in self.buttons.items():button.set_active(index==self.active_index); self.indicators[index].set_visible(index==self.active_index)
        finally:self.syncing=False
    def set_active(self,index):
        self.active_index=index if index is not None and 0<=index<len(self.owner.saved_palettes) else None
        self.label.set_text(self.owner.saved_palettes[self.active_index]["name"] if self.active_index is not None else "Choose saved palette"); self.update_selection()
    def clear_active(self):self.set_active(None)
class CompactCount(Gtk.Box):
    def __init__(self,owner,minimum=2,maximum=8,value=5):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL,spacing=1); self.minimum=minimum; self.maximum=maximum; self.value=value; self.callbacks=[]
        self.minus=owner._icon_button("minus","Remove one swatch",lambda *_:self.set_value(self.value-1),28); self.pack_start(self.minus,False,False,0)
        self.entry=Gtk.Entry(); self.entry.set_width_chars(2); self.entry.set_max_width_chars(2); self.entry.set_size_request(30,30); self.entry.set_alignment(.5); self.entry.set_text(str(value)); self.entry.connect("activate",self.commit); self.entry.connect("focus-out-event",self.commit); self.pack_start(self.entry,False,False,0)
        self.plus=owner._icon_button("add","Add one swatch",lambda *_:self.set_value(self.value+1),28); self.pack_start(self.plus,False,False,0)
    def get_value(self):return self.value
    def set_value(self,value):
        next_value=max(self.minimum,min(self.maximum,int(round(value)))); changed=next_value!=self.value; self.value=next_value; self.entry.set_text(str(next_value)); self.minus.set_sensitive(next_value>self.minimum); self.plus.set_sensitive(next_value<self.maximum)
        if changed:
            for callback in self.callbacks:callback(self)
    def connect_changed(self,callback):self.callbacks.append(callback)
    def commit(self,*_args):
        try:self.set_value(int(self.entry.get_text()))
        except ValueError:self.entry.set_text(str(self.value))
        return False
class ColorWheel(Gtk.DrawingArea):
    LIGHT_MIN=.08; LIGHT_MAX=.92
    def __init__(self,owner):
        super().__init__(); self.owner=owner; self.set_size_request(320,320)
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK|Gdk.EventMask.POINTER_MOTION_MASK|Gdk.EventMask.BUTTON1_MOTION_MASK)
        self.connect("draw",self.draw_wheel); self.connect("button-press-event",self.pick); self.connect("motion-notify-event",self.drag)
    def metrics(self):
        size=min(self.get_allocated_width(),self.get_allocated_height()); outer=size*.46; inner=outer*.65
        return self.get_allocated_width()/2,self.get_allocated_height()/2,inner,outer
    def color_point(self,color,cx,cy,inner,outer):
        hue,light,_sat=hex_to_hls(color); t=_clamp((light-self.LIGHT_MIN)/(self.LIGHT_MAX-self.LIGHT_MIN)); radius=inner+(outer-inner)*t
        angle=math.radians(hue); return {"color":color,"hue":hue,"radius":radius,"angle":angle,"x":cx+math.cos(angle)*radius,"y":cy+math.sin(angle)*radius}
    def resolve_collisions(self,points,cx,cy,inner,outer,fixed_index=None):
        placed=[]; resolved=[None]*len(points); order=list(range(len(points)))
        if fixed_index is not None:order.remove(fixed_index); order.insert(0,fixed_index)
        for index in order:
            point=points[index]; candidate=dict(point); attempt=0
            while any(_distance((candidate["x"],candidate["y"]),(other["x"],other["y"]))<19 for other in placed) and attempt<40:
                step=(attempt//2+1)*math.radians(5); angle=point["angle"]+(step if attempt%2 else -step)
                radius=_clamp(point["radius"]+((attempt%3)-1)*3,inner+2,outer-2)
                candidate.update(angle=angle,radius=radius,x=cx+math.cos(angle)*radius,y=cy+math.sin(angle)*radius); attempt+=1
            resolved[index]=candidate; placed.append(candidate)
        return resolved
    def connectors(self,points):
        if len(points)<2 or (not self.owner.recipe_active() and self.owner.rule_id() in {"tint","shade","tone","monochromatic"}): return []
        # Collision resolution may move repeated hues slightly; order by the final
        # polar angle so the perimeter cannot self-intersect.
        center_x=sum(p["x"] for p in points)/len(points); center_y=sum(p["y"] for p in points)/len(points)
        ordered=sorted(points,key=lambda p:math.atan2(p["y"]-center_y,p["x"]-center_x)); pairs=list(zip(ordered,ordered[1:]))
        if len(ordered)>2: pairs.append((ordered[-1],ordered[0]))
        return pairs
    def draw_wheel(self,_widget,cr):
        cx,cy,inner,outer=self.metrics(); rings,segments=14,180
        for ring in range(rings):
            r1=inner+(outer-inner)*ring/rings; r2=inner+(outer-inner)*(ring+1)/rings+1
            light=self.LIGHT_MIN+(self.LIGHT_MAX-self.LIGHT_MIN)*(ring+.5)/rings
            for segment in range(segments):
                a1=2*math.pi*segment/segments; a2=2*math.pi*(segment+1)/segments+.01
                red,green,blue=colorsys.hls_to_rgb(segment/segments,light,.9); cr.set_source_rgb(red,green,blue); cr.set_line_width(r2-r1); cr.arc(cx,cy,(r1+r2)/2,a1,a2); cr.stroke()
        # Paint the hole first so connectors remain fully visible over it.
        cr.set_source_rgb(*self.owner.background_rgb()); cr.arc(cx,cy,inner-2,0,2*math.pi); cr.fill()
        generated=self.owner.display_colors(); raw=[self.color_point(color,cx,cy,inner,outer) for color in generated]
        exact=next((i for i,color in enumerate(generated) if color.upper()==self.owner.color.upper()),None); active_point=self.color_point(self.owner.color,cx,cy,inner,outer); points=self.resolve_collisions(raw,cx,cy,inner,outer,exact)
        fg=(.96,.96,.98) if self.owner.dark_mode() else (.08,.09,.12); outline=(.08,.09,.12) if self.owner.dark_mode() else (.98,.98,.98); connectors=self.connectors(points)
        cr.set_line_cap(1)
        for color,width,alpha in ((outline,3.4,.76),(fg,1.45,1)):
            cr.set_source_rgba(*color,alpha); cr.set_line_width(width)
            for start,end in connectors: cr.move_to(start["x"],start["y"]); cr.line_to(end["x"],end["y"]); cr.stroke()
        for index,point in enumerate(points):
            is_active=index==exact; marker_color=self.owner.color if is_active else point["color"]; radius=11 if is_active else 6.8; red,green,blue=[int(marker_color[i:i+2],16)/255 for i in (1,3,5)]; border=2 if is_active else 1.7
            cr.set_source_rgb(*fg); cr.arc(point["x"],point["y"],radius+border,0,2*math.pi); cr.fill(); cr.set_source_rgb(red,green,blue); cr.arc(point["x"],point["y"],radius,0,2*math.pi); cr.fill()
        if exact is None:
            red,green,blue=[int(self.owner.color[i:i+2],16)/255 for i in (1,3,5)]; cr.set_source_rgb(*fg); cr.arc(active_point["x"],active_point["y"],13,0,2*math.pi); cr.fill(); cr.set_source_rgb(red,green,blue); cr.arc(active_point["x"],active_point["y"],11,0,2*math.pi); cr.fill()
        return False
    def _set(self,event):
        cx,cy,inner,outer=self.metrics(); dx,dy=event.x-cx,event.y-cy; distance=math.hypot(dx,dy)
        if inner<=distance<=outer:
            hue=math.degrees(math.atan2(dy,dx))%360; light=self.LIGHT_MIN+(self.LIGHT_MAX-self.LIGHT_MIN)*_clamp((distance-inner)/(outer-inner))
            _h,_l,sat=hex_to_hls(self.owner.color); self.owner.set_color(hls_to_hex(hue,light,max(.35,sat)))
    def pick(self,_widget,event): self._set(event); return True
    def drag(self,_widget,event):
        if event.state&Gdk.ModifierType.BUTTON1_MASK:self._set(event)
        return True

class NativePickerHud(Gtk.DrawingArea):
    WIDTH=300; HEIGHT=124
    def __init__(self):
        super().__init__(); self.color="#000000"; self.set_size_request(self.WIDTH,self.HEIGHT); self.connect("draw",self.draw_hud)
    def update_sample(self,color):
        if color!=self.color:self.color=color; self.queue_draw()
    @staticmethod
    def rounded(cr,x,y,width,height,radius):
        cr.new_sub_path(); cr.arc(x+width-radius,y+radius,radius,-math.pi/2,0); cr.arc(x+width-radius,y+height-radius,radius,0,math.pi/2); cr.arc(x+radius,y+height-radius,radius,math.pi/2,math.pi); cr.arc(x+radius,y+radius,radius,math.pi,math.pi*1.5); cr.close_path()
    @staticmethod
    def text(cr,text,x,y,size,bold=False):
        cr.select_font_face("Sans",0,1 if bold else 0); cr.set_font_size(size); cr.move_to(x,y); cr.show_text(text)
    def draw_hud(self,_widget,cr):
        self.rounded(cr,1,1,self.WIDTH-2,self.HEIGHT-2,10); cr.set_source_rgba(.20,.21,.23,.88); cr.fill()
        cr.set_source_rgb(1,1,1); self.text(cr,"Color Picking Mode",15,22,17,True); cr.set_source_rgb(.88,.89,.91); self.text(cr,"Click to select  ·  Esc to cancel",15,39,12)
        red,green,blue=[int(self.color[i:i+2],16) for i in (1,3,5)]; hue,light,saturation=hex_to_hls(self.color); cr.set_source_rgb(red/255,green/255,blue/255); cr.rectangle(17,54,56,56); cr.fill(); cr.set_source_rgb(.94,.95,.97); cr.set_line_width(3); cr.rectangle(18.5,55.5,53,53); cr.stroke()
        cr.set_source_rgb(1,1,1); self.text(cr,self.color,88,70,16,True); cr.set_source_rgb(.90,.91,.93); self.text(cr,f"RGB  {red}  {green}  {blue}",88,91,12); self.text(cr,f"HSL  {round(hue)}  {round(saturation*100)}%  {round(light*100)}%",88,108,12)
        return False
class HuePrintDialog(Gtk.Dialog):
    def __init__(self):
        super().__init__(title="HuePrint © — 1.4.5",flags=0); self.set_default_size(1,900); self.set_resizable(True)
        self.add_button("Cancel",Gtk.ResponseType.CANCEL)
        try:
            icon=GdkPixbuf.Pixbuf.new_from_file_at_scale(str(Path(__file__).with_name("hueprint-icon.svg")),32,32,True); self.set_icon(icon); Gtk.Window.set_default_icon(icon)
        except (GLib.Error,OSError):pass
        self.color="#2F80ED"; self.saved=self._load_saved(); self.saved_palettes=self._load_saved_palettes(); self.custom_palette=None; self.custom_palette_template=None; self.custom_palette_anchor=None; self.updating_lightness=False; self.lightness_refresh_id=None; self.random_state=None; self.random_undo=None; self.random_redo=None; self.icon_buttons=[]; self.picker_window=None; self.picker_hud=None; self.picker_sampler=None; self.picker_timer_id=None; self.picker_armed=False; self.picker_position=None; self.picker_pending=False; self.hairline_provider=Gtk.CssProvider(); self.lightness_provider=Gtk.CssProvider(); self.initial_dark=_inkscape_prefers_dark(); settings=Gtk.Settings.get_default()
        if settings:settings.set_property("gtk-application-prefer-dark-theme",self.initial_dark)
        self.connect("key-press-event",self.history_key)
        self._build(); self.refresh()
    def described_combo(self,items,wrap=0):return DescribedChooser(items,wrap or 1)
    def _build(self):
        root=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=8); root.set_border_width(14); self.get_content_area().pack_start(root,True,True,0)
        header=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=8)
        title_box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=0); self.main_title=Gtk.Label(); self.main_title.set_markup("<span size='28000' weight='bold'>HuePrint ©</span>"); self.main_title.set_xalign(0); self.main_title.get_style_context().add_class("hueprint-title"); title_box.pack_start(self.main_title,False,False,0)
        subtitle=Gtk.Label(); subtitle.set_markup("<span line_height='0.95'><span size='10000'>Color harmony &amp; palette studio · 1.4.5 · © 2026 Winton Diaz Dauhajre</span>\n<span size='10000'>Hover over any harmony or recipe for details. Drag the color wheel to change hue and lightness.</span></span>"); subtitle.set_xalign(0); title_box.pack_start(subtitle,False,False,0)
        header.pack_start(title_box,True,True,0)
        self.theme_toggle=Gtk.ToggleButton(); self.theme_toggle.set_size_request(36,36); self.theme_toggle.set_valign(Gtk.Align.CENTER); self.theme_toggle.set_active(self.initial_dark); _set_icon(self.theme_toggle,"sun" if self.theme_toggle.get_active() else "moon"); self.theme_toggle.connect("toggled",self.theme_changed); header.pack_end(self.theme_toggle,False,False,0); root.pack_start(header,False,False,0)
        workspace=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=18); root.pack_start(workspace,True,True,0)
        self.wheel=ColorWheel(self); workspace.pack_start(self.wheel,True,True,0)
        controls=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=10); controls.set_size_request(470,-1); controls.set_valign(Gtk.Align.CENTER); workspace.pack_start(controls,False,False,0)
        active=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=5); self.active_swatch=Gtk.DrawingArea(); self.active_swatch.set_size_request(36,32); self.active_swatch.connect("draw",self.draw_active_swatch); active.pack_start(self.active_swatch,False,False,0)
        self.color_entry=Gtk.Entry(); self.color_entry.set_width_chars(7); self.color_entry.set_max_width_chars(7); self.color_entry.set_size_request(82,-1); self.color_entry.set_text(self.color); self.color_entry.connect("activate",self.entry_changed); active.pack_start(self.color_entry,False,False,0)
        lightness_label=Gtk.Label(label="L"); lightness_label.set_tooltip_text("Lightness"); active.pack_start(lightness_label,False,False,0); self.lightness=Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL,8,92,1); self.lightness.set_name("hueprint-lightness"); self.lightness.get_style_context().add_provider(self.lightness_provider,Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION); self.lightness.set_draw_value(False); self.lightness.set_size_request(170,-1); self.lightness.set_hexpand(True); self.lightness.set_tooltip_text("Active color lightness"); self.lightness.set_value(hex_to_hls(self.color)[1]*100); self.lightness.connect("value-changed",self.lightness_changed); self.lightness.connect("button-release-event",self.lightness_released); active.pack_start(self.lightness,True,True,0)
        self.add_active_button=self._icon_button("add","Add active color to Saved Swatches",self.add_active); active.pack_start(self.add_active_button,False,False,0)
        self.color_button=self._icon_button("dropper","Pick a color anywhere on the active screen",self.start_screen_pick); active.pack_start(self.color_button,False,False,0)
        self.copy_button=self._icon_button("copy","Copy active color",self.copy_color); active.pack_start(self.copy_button,False,False,0); controls.pack_start(self._row("Active Color",active,17363),False,False,0)
        selectors=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=8)
        self.harmony=HarmonyBrowser(self); self.harmony.set_hexpand(True); self.harmony.connect_changed(self.harmony_changed); selectors.pack_start(self._row("Harmony",self.harmony),True,True,0)
        self.recipe=RecipeBrowser(self); self.recipe.set_hexpand(True); self.recipe.connect_changed(self.control_changed); selectors.pack_start(self._row("Palette recipe",self.recipe),True,True,0)
        self.saved_palette=SavedPaletteBrowser(self); self.saved_palette.set_hexpand(True); self.saved_palette.set_tooltip_text("Load a saved palette into Current Palette"); selectors.pack_start(self._row("Saved Palettes",self.saved_palette),True,True,0); controls.pack_start(selectors,False,False,0)
        apply_line=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=10); self.apply_fill=Gtk.CheckButton(label="Fill"); self.apply_fill.set_active(True); apply_line.pack_start(self.apply_fill,False,False,0)
        self.apply_stroke=Gtk.CheckButton(label="Stroke"); apply_line.pack_start(self.apply_stroke,False,False,0); self.create=Gtk.CheckButton(label="Create swatches on canvas"); self.create.set_active(True); apply_line.pack_start(self.create,False,False,0)
        for option in (self.apply_fill,self.apply_stroke,self.create):option.connect("toggled",self.application_option_toggled)
        self.apply_button=Gtk.Button(label="Apply"); self.apply_button.set_tooltip_text("Apply the Current Palette using every selected action"); self.apply_button.connect("clicked",lambda *_:self.response(Gtk.ResponseType.APPLY)); apply_line.pack_end(self.apply_button,False,False,0); controls.pack_start(self._row("Apply Colors To",apply_line),False,False,0)
        swatch_separator=self._hairline(14,8); root.pack_start(swatch_separator,False,False,0)
        swatch_header=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=8); swatch_title=Gtk.Label(); swatch_title.set_markup("<span size='17363' weight='bold'>Current Palette</span>"); swatch_title.set_xalign(0); swatch_title.get_style_context().add_class("hueprint-title"); swatch_header.pack_start(swatch_title,False,False,0)
        self.count=CompactCount(self,2,16,5); self.count.connect_changed(self.control_changed); swatch_header.pack_end(self.count,False,False,0); root.pack_start(swatch_header,False,False,0)
        self.metadata_grid=Gtk.Grid(); self.metadata_grid.set_row_spacing(0); self.metadata_grid.set_column_spacing(7); self.metadata_grid.set_column_homogeneous(True); root.pack_start(self.metadata_grid,False,False,0)
        saved_separator=self._hairline(12,8); root.pack_start(saved_separator,False,False,0)
        saved_header=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=8); saved_title=Gtk.Label(); saved_title.set_markup("<span size='17363' weight='bold'>Saved Swatches</span>"); saved_title.set_xalign(0); saved_title.get_style_context().add_class("hueprint-title"); saved_header.pack_start(saved_title,True,True,0)
        for icon,tooltip,handler in (("use","Load Saved Swatches as Current Palette before applying them to Inkscape",self.use_saved_palette),("palette","Add Current Palette to Saved Swatches",self.save_generated),("import","Import colors into Saved Swatches",self.import_palette),("export","Export Saved Swatches as an Inkscape palette",self.export_palette),("save","Save Saved Swatches as a reusable palette",self.save_saved_palette),("trash","Clear Saved Swatches",self.clear_saved)):
            saved_header.pack_start(self._icon_button(icon,tooltip,handler),False,False,0)
        root.pack_start(saved_header,False,False,0)
        saved_help=Gtk.Label(label="To send these swatches to Inkscape, load them as Current Palette, choose the Apply options, then click Apply."); saved_help.set_xalign(0); saved_help.set_line_wrap(True); root.pack_start(saved_help,False,False,0)
        self.saved_box=Gtk.FlowBox(); self.saved_box.set_selection_mode(Gtk.SelectionMode.NONE); self.saved_box.set_column_spacing(5); self.saved_box.set_row_spacing(5); self.saved_box.set_min_children_per_line(8); self.saved_box.set_max_children_per_line(8); self.saved_box.set_homogeneous(True); root.pack_start(self.saved_box,False,False,0)
        self.show_all(); self.theme_changed()
    def _row(self,label,widget,size=14840):
        box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=3); text=Gtk.Label(); text.set_markup(f"<span size='{size}' weight='bold'>{label}</span>"); text.set_xalign(0); text.get_style_context().add_class("hueprint-title"); box.pack_start(text,False,False,0); box.pack_start(widget,False,False,0); return box
    def application_option_toggled(self,button):
        options=(self.apply_fill,self.apply_stroke,self.create)
        if not any(option.get_active() for option in options):button.set_active(True)
    def _icon_button(self,icon,tooltip,handler,size=32,stroke=None):
        button=Gtk.Button(); button.set_size_request(size,size); button.set_valign(Gtk.Align.CENTER); button.set_relief(Gtk.ReliefStyle.NONE if size<=24 else Gtk.ReliefStyle.NORMAL)
        if size<=24:
            context=button.get_style_context(); context.add_class("hueprint-mini-icon"); context.add_provider(self.hairline_provider,Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        _set_icon(button,icon,16 if size>=30 else 13,stroke); button.set_tooltip_text(tooltip); button.connect("clicked",handler); self.icon_buttons.append(button); return button
    def _hairline(self,top,bottom,table=False):
        separator=Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL); separator.set_margin_top(top); separator.set_margin_bottom(bottom); context=separator.get_style_context(); context.add_class("hueprint-table-hairline" if table else "hueprint-section-hairline"); context.add_provider(self.hairline_provider,Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION); return separator
    def dark_mode(self): return self.theme_toggle.get_active()
    def background_rgb(self):
        found,color=self.get_style_context().lookup_color("theme_bg_color"); return (color.red,color.green,color.blue) if found else ((.2,.2,.2) if self.dark_mode() else (.96,.96,.96))
    def theme_changed(self,*_args):
        dark=self.dark_mode(); settings=Gtk.Settings.get_default()
        if settings:settings.set_property("gtk-application-prefer-dark-theme",dark)
        if dark:
            css=".hueprint-title, .hueprint-active-heading { color: #FFFFFF; } .hueprint-section-hairline { background-color: rgba(255,255,255,0.42); min-height: 1px; } .hueprint-table-hairline { background-color: rgba(255,255,255,0.17); min-height: 1px; } .hueprint-mini-icon { padding: 0; min-width: 20px; min-height: 20px; }"
        else:
            css=".hueprint-title, .hueprint-active-heading { color: #090909; } button { color: #171A1F; background-image: none; background-color: #F4F5F7; border-color: #C8CDD4; text-shadow: none; box-shadow: none; } button label { color: #171A1F; } button:hover { background-color: #E7E9ED; } button:active, button:checked { background-color: #DCE1E7; border-color: #AEB5BF; } button:disabled { color: #8B929C; background-color: #ECEEF1; } .hueprint-section-hairline { background-color: rgba(20,30,45,0.34); min-height: 1px; } .hueprint-table-hairline { background-color: rgba(20,30,45,0.13); min-height: 1px; } .hueprint-mini-icon { padding: 0; min-width: 20px; min-height: 20px; }"
        self.hairline_provider.load_from_data(css.encode("utf-8"))
        if not getattr(self,"theme_provider_registered",False):
            Gtk.StyleContext.add_provider_for_screen(self.get_screen(),self.hairline_provider,Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION); self.theme_provider_registered=True
        _set_icon(self.theme_toggle,"sun" if dark else "moon"); self.theme_toggle.set_tooltip_text("Switch to light mode" if dark else "Switch to dark mode")
        for button in self.icon_buttons:_set_icon(button,button.hueprint_icon,button.hueprint_icon_size,getattr(button,"hueprint_icon_stroke",None))
        self.update_lightness_gradient(); self.wheel.queue_draw()
    def recipe_active(self): return self.recipe.get_active_id() not in (None,"none")
    def rule_id(self): return self.harmony.get_active_id() or "analogous"
    def clear_custom_palette(self):
        if self.custom_palette is not None:self.custom_palette=None
        self.custom_palette_template=None; self.custom_palette_anchor=None
        if hasattr(self,"saved_palette"):self.saved_palette.clear_active()
    def retarget_custom_palette(self,next_color):
        if self.custom_palette is None:return False
        template=self.custom_palette_template or self.custom_palette; anchor=self.custom_palette_anchor or self.color
        self.custom_palette=translate_palette_geometry(template,anchor,next_color); return True
    def display_colors(self):
        return self.generated_colors()
    def expand_for_palette(self,count):
        screen_width=self.get_screen().get_width() if self.get_screen() else 1920
        current_width=max(1,self.get_allocated_width()); current_height=max(900,self.get_allocated_height())
        target_width=min(screen_width-48,max(current_width,360+count*82))
        self.resize(target_width,current_height)
        return False
    def use_saved_palette(self,*_args):
        if not self.saved:return
        self.clear_random_palette(); self.saved_palette.clear_active(); self.custom_palette=list(self.saved); self.custom_palette_template=list(self.custom_palette); self.custom_palette_anchor=self.custom_palette[0]
        if self.recipe_active():self.recipe.set_active_id("none")
        self.set_color(self.custom_palette[0],preserve_custom=True)
        GLib.idle_add(self.expand_for_palette,len(self.custom_palette))
    def generated_colors(self):
        if self.custom_palette is not None:return list(self.custom_palette)
        count=int(self.count.get_value()) if hasattr(self,"count") else 5; recipe=self.recipe.get_active_id() if hasattr(self,"recipe") else "none"
        if self.random_state is not None:colors=list(self.random_state["colors"])
        else:colors=generate_recipe(self.color,recipe) if recipe not in (None,"none") else generate_palette(self.color,self.rule_id(),count)
        colors=list(colors[:count]); originals=list(colors); offsets=(-.14,.14,-.24,.24)
        while len(colors)<count:
            base=originals[len(colors)%len(originals)]; hue,light,saturation=hex_to_hls(base); offset=offsets[(len(colors)-len(originals))%len(offsets)]
            colors.append(hls_to_hex(hue,_clamp(light+offset,.08,.92),saturation*.82))
        seen={}
        for index,color in enumerate(colors):
            repeat=seen.get(color,0); seen[color]=repeat+1
            if repeat:
                hue,light,saturation=hex_to_hls(color); offset=offsets[(repeat-1)%len(offsets)]; hue+=3*((repeat-1)//len(offsets))
                colors[index]=hls_to_hex(hue,_clamp(light+offset,.08,.92),saturation*.88)
        return colors
    def active_point_index(self,colors):
        active=self.color.upper(); return next((i for i,color in enumerate(colors) if color.upper()==active),0)
    def harmony_changed(self,*_args):
        self.clear_custom_palette()
        self.clear_random_palette()
        if hasattr(self,"recipe") and self.recipe_active():self.recipe.set_active_id("none")
        else:self.refresh()
    def control_changed(self,control,*_args):
        if control is self.count:
            self.clear_random_palette();self.clear_custom_palette()
            GLib.idle_add(self.expand_for_palette,int(self.count.get_value()))
        self.refresh()
    def clear_random_palette(self):
        if self.random_state is not None:
            self.random_state=None
            if hasattr(self,"recipe"):self.recipe.label.set_text("Choose recipe" if self.recipe.get_active_id()=="none" else RECIPE_METADATA_BY_ID[self.recipe.get_active_id()].display_name)
    def palette_snapshot(self):return (self.recipe.get_active_id(),self.random_state)
    def restore_palette_snapshot(self,snapshot):
        recipe_id,state=snapshot; self.recipe.set_active_id(recipe_id); self.random_state=state; self.recipe.label.set_text("Randomized Palette" if state else ("Choose recipe" if recipe_id=="none" else RECIPE_METADATA_BY_ID[recipe_id].display_name)); self.refresh()
    def randomize_palette(self,active_filter):
        self.clear_custom_palette()
        chooser=random.SystemRandom(); categories=list(CATEGORY_ORDER[1:])
        if active_filter=="all":category=chooser.choices(categories,weights=(12,16,12,12,10,16,12,6,4,15,18,15),k=1)[0]
        else:category=active_filter
        recipe_id=chooser.choice(RECIPE_IDS_BY_CATEGORY[category]); previous=self.palette_snapshot(); self.recipe.set_active_id(recipe_id); state=randomize_recipe(self.color,recipe_id,category,int(self.count.get_value())); self.random_undo=previous; self.random_redo=None; self.random_state=state; self.recipe.label.set_text("Randomized Palette"); self.refresh()
    def history_key(self,_widget,event):
        if not event.state&Gdk.ModifierType.CONTROL_MASK:return False
        if event.keyval in (Gdk.KEY_z,Gdk.KEY_Z) and not event.state&Gdk.ModifierType.SHIFT_MASK and self.random_undo is not None:current=self.palette_snapshot(); snapshot=self.random_undo; self.random_undo=None; self.random_redo=current; self.restore_palette_snapshot(snapshot); return True
        if event.keyval in (Gdk.KEY_y,Gdk.KEY_Y) or (event.keyval in (Gdk.KEY_z,Gdk.KEY_Z) and event.state&Gdk.ModifierType.SHIFT_MASK):
            if self.random_redo is not None:current=self.palette_snapshot(); snapshot=self.random_redo; self.random_redo=None; self.random_undo=current; self.restore_palette_snapshot(snapshot); return True
        return False
    def update_lightness_gradient(self):
        if not hasattr(self,"lightness"):return
        hue,_light,saturation=hex_to_hls(self.color); stops=[hls_to_hex(hue,value,saturation) for value in (.08,.28,.50,.72,.92)]; css="#hueprint-lightness trough { min-height: 7px; background-image: linear-gradient(to right, %s); } #hueprint-lightness highlight { background-color: transparent; background-image: none; }"%", ".join(stops); self.lightness_provider.load_from_data(css.encode("utf-8"))
    def set_color(self,color,preserve_custom=False):
        self.clear_random_palette(); next_color=sanitize_hex(color)
        if not preserve_custom:
            if self.custom_palette is not None:self.retarget_custom_palette(next_color)
            else:self.clear_custom_palette()
        self.color=next_color; self.color_entry.set_text(self.color); self.updating_lightness=True
        if hasattr(self,"lightness"):self.lightness.set_value(hex_to_hls(self.color)[1]*100)
        self.updating_lightness=False; self.cancel_lightness_refresh(); self.update_lightness_gradient(); _set_icon(self.copy_button,"copy"); self.copy_button.set_tooltip_text("Copy active color"); self.active_swatch.queue_draw(); self.refresh()
    def cancel_lightness_refresh(self):
        if self.lightness_refresh_id is not None:GLib.source_remove(self.lightness_refresh_id); self.lightness_refresh_id=None
    def finish_lightness_refresh(self):
        self.lightness_refresh_id=None; self.refresh(); return False
    def lightness_changed(self,scale):
        if self.updating_lightness:return
        self.clear_random_palette(); hue,_light,saturation=hex_to_hls(self.color); next_color=hls_to_hex(hue,scale.get_value()/100,saturation)
        if self.custom_palette is not None:self.retarget_custom_palette(next_color)
        else:self.clear_custom_palette()
        self.color=next_color; self.color_entry.set_text(self.color); self.update_lightness_gradient(); _set_icon(self.copy_button,"copy"); self.copy_button.set_tooltip_text("Copy active color"); self.active_swatch.queue_draw(); self.wheel.queue_draw(); self.cancel_lightness_refresh(); self.lightness_refresh_id=GLib.timeout_add(40,self.finish_lightness_refresh)
    def lightness_released(self,*_args):
        self.cancel_lightness_refresh(); self.refresh(); self.set_focus(None); return False
    def entry_changed(self,entry):self.set_color(entry.get_text())
    def select_palette_color(self,color):
        preserve=self.custom_palette is not None
        if preserve:self.custom_palette_template=list(self.custom_palette); self.custom_palette_anchor=sanitize_hex(color)
        self.set_color(color,preserve_custom=preserve)
    def start_screen_pick(self,*_args):
        if self.picker_window is not None or self.picker_pending:return
        self.picker_pending=True; self.color_button.set_sensitive(False); GLib.idle_add(self.open_screen_picker)
    def open_screen_picker(self):
        try:
            sampler=NativeScreenSampler(); self.picker_sampler=sampler; x,y=sampler.position(); color=sampler.color_at(x,y)
            window=Gtk.Window(type=Gtk.WindowType.TOPLEVEL); window.set_decorated(False); window.set_transient_for(self); window.set_destroy_with_parent(True); window.set_keep_above(True); window.set_skip_taskbar_hint(True); window.set_skip_pager_hint(True); window.set_accept_focus(False); window.set_focus_on_map(False); window.set_resizable(False); screen=window.get_screen(); visual=screen.get_rgba_visual() if screen and screen.is_composited() else None
            if visual is not None:window.set_visual(visual); window.set_app_paintable(True)
            hud=NativePickerHud(); hud.update_sample(color); window.add(hud); self.picker_window=window; self.picker_hud=hud; self.picker_position=(x,y); self.picker_armed=False
            window.show_all(); self.position_picker_hud(x,y)
            if not sampler.pressed(NativeScreenSampler.VK_LBUTTON):sampler.arm(); self.picker_armed=True
            self.picker_timer_id=GLib.timeout_add(40,self.poll_screen_picker); self.picker_pending=False
        except Exception as error:
            print("HuePrint color picker:",error,file=sys.stderr); self.close_screen_picker(); self.restore_after_picker()
        return False
    def position_picker_hud(self,x,y):
        if self.picker_window is None or self.picker_sampler is None:return
        sampler=self.picker_sampler; width,height=NativePickerHud.WIDTH,NativePickerHud.HEIGHT; right=sampler.left+sampler.width; bottom=sampler.top+sampler.height; px=x+28; py=y+28
        if px+width>right-10:px=x-width-28
        if py+height>bottom-10:py=y-height-28
        self.picker_window.move(max(sampler.left+10,min(px,right-width-10)),max(sampler.top+10,min(py,bottom-height-10)))
    def poll_screen_picker(self):
        try:
            sampler=self.picker_sampler
            if sampler is None:return False
            if sampler.key_state(NativeScreenSampler.VK_ESCAPE)&0x8001:
                self.picker_timer_id=None; self.close_screen_picker(); GLib.idle_add(self.restore_after_picker); return False
            clicked=sampler.take_click()
            if clicked is not None:
                color=sampler.color_at(*clicked); self.picker_timer_id=None; self.close_screen_picker(); GLib.idle_add(self.commit_screen_pick,color); return False
            if not self.picker_armed and not sampler.pressed(NativeScreenSampler.VK_LBUTTON):sampler.arm(); self.picker_armed=True
            position=sampler.position()
            if position!=self.picker_position:
                color=sampler.color_at(*position); self.picker_hud.update_sample(color); self.position_picker_hud(*position); self.picker_position=position
            return True
        except Exception as error:
            print("HuePrint color picker:",error,file=sys.stderr); self.picker_timer_id=None; self.close_screen_picker(); GLib.idle_add(self.restore_after_picker); return False
    def close_screen_picker(self):
        if self.picker_timer_id is not None:GLib.source_remove(self.picker_timer_id); self.picker_timer_id=None
        window=self.picker_window; sampler=self.picker_sampler; self.picker_window=None; self.picker_hud=None; self.picker_sampler=None; self.picker_armed=False; self.picker_position=None
        if window is not None:window.hide(); window.destroy()
        if sampler is not None:sampler.close()
    def commit_screen_pick(self,color):self.set_color(color); return self.restore_after_picker()
    def restore_after_picker(self):self.picker_pending=False; self.color_button.set_sensitive(True); self.present(); return False
    def copy_color(self,*_args):
        Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).set_text(self.color,-1); _set_icon(self.copy_button,"check"); self.copy_button.set_tooltip_text("Color copied")
    def draw_active_swatch(self,widget,cr):
        red,green,blue=[int(self.color[i:i+2],16)/255 for i in (1,3,5)]; cr.set_source_rgb(red,green,blue); cr.rectangle(0,0,widget.get_allocated_width(),widget.get_allocated_height()); cr.fill(); return False
    def _color_widget(self,color,height,handler=None):
        event=Gtk.EventBox(); event.set_hexpand(True); event.set_halign(Gtk.Align.FILL); area=Gtk.DrawingArea(); area.set_size_request(36,height); area.set_hexpand(True); red,green,blue=[int(color[i:i+2],16)/255 for i in (1,3,5)]
        area.connect("draw",lambda w,cr:(cr.set_source_rgb(red,green,blue),cr.rectangle(0,0,w.get_allocated_width(),w.get_allocated_height()),cr.fill(),False)[-1]); event.add(area); event.set_tooltip_text(color)
        if handler:event.connect("button-press-event",lambda *_:handler(color))
        return event
    def refresh(self):
        if not hasattr(self,"metadata_grid"):return
        colors=self.generated_colors(); self.harmony.refresh_previews(); self.recipe.refresh_previews(); self.render_metadata(colors); self.render_saved(); self.wheel.queue_draw()
    def _metadata(self,color):
        h,l,s=hex_to_hls(color); r,g,b=[int(color[i:i+2],16) for i in (1,3,5)]; rn,gn,bn=r/255,g/255,b/255; k=1-max(rn,gn,bn)
        c=m=y=0 if k>=.999 else None
        if k<.999:c=(1-rn-k)/(1-k);m=(1-gn-k)/(1-k);y=(1-bn-k)/(1-k)
        ok_l,ok_c,ok_h=hex_to_oklch(color)
        return {"HEX":color,"RGB":f"{r}\n{g}\n{b}","CMYK":f"{round(c*100)}%\n{round(m*100)}%\n{round(y*100)}%\n{round(k*100)}%","HSL":f"{round(h)}°\n{round(s*100)}%\n{round(l*100)}%","OKLCH":f"{ok_l:.3f}\n{ok_c:.3f}\n{round(ok_h)}°"}
    def _table_label(self,markup,align=1):
        label=Gtk.Label(); label.set_markup(f"<span line_height='0.85'>{markup}</span>"); label.set_xalign(align); label.set_yalign(0); label.set_hexpand(True); label.set_halign(Gtk.Align.FILL)
        if align>=.99:label.set_justify(Gtk.Justification.RIGHT)
        layout=label.get_layout()
        if hasattr(layout,"set_line_spacing"):layout.set_line_spacing(.85)
        return label
    def render_metadata(self,colors):
        for child in self.metadata_grid.get_children():self.metadata_grid.remove(child)
        other_colors=list(colors); active_index=next((i for i,color in enumerate(other_colors) if color.upper()==self.color.upper()),0)
        if other_colors:other_colors.pop(active_index)
        generated_columns=[(str(i),color) for i,color in enumerate(other_colors,start=2)]; columns=[("Active",self.color)]+generated_columns; channel={"HEX":"","RGB":"R\nG\nB","CMYK":"C\nM\nY\nK","HSL":"H\nS\nL","OKLCH":"L\nC\nH"}; total=len(columns)+2
        for col,title in enumerate(("Format","Parts")):
            heading=self._table_label(f"<span size='large' weight='bold'>{title}</span>"); heading.set_yalign(1); heading.set_margin_bottom(6); heading.set_margin_end(16 if col==1 else 0); self.metadata_grid.attach(heading,col,1,1,1)
        for col,(name,color) in enumerate(columns,2):
            header=self._table_label(f"<span size='14840' weight='bold'>{name}</span>",1)
            if name=="Active":header.get_style_context().add_class("hueprint-active-heading")
            header.set_size_request(53,-1); header.set_margin_start(16 if col==2 else 0); self.metadata_grid.attach(header,col,0,1,1)
            swatch=self._color_widget(color,30,self.select_palette_color); swatch.set_margin_top(5); swatch.set_margin_bottom(6); swatch.set_margin_start(16 if col==2 else 0); self.metadata_grid.attach(swatch,col,1,1,1)
        for index,kind in enumerate(("HEX","RGB","CMYK","HSL","OKLCH")):
            separator=self._hairline(4,4,table=True); self.metadata_grid.attach(separator,0,2+index*2,total,1)
            row=3+index*2; self.metadata_grid.attach(self._table_label(f"<span size='large' weight='bold'>{kind}</span>"),0,row,1,1)
            parts=self._table_label(f"<span size='medium' weight='bold'>{channel[kind]}</span>"); parts.set_margin_end(16); self.metadata_grid.attach(parts,1,row,1,1)
            for col,(_name,color) in enumerate(columns,2):
                value=self._table_label(f"<span size='medium'>{self._metadata(color)[kind]}</span>"); value.set_selectable(True); value.set_margin_start(16 if col==2 else 0); self.metadata_grid.attach(value,col,row,1,1)
        self.metadata_grid.show_all()
    def _load_saved_palettes(self):
        for path in (_saved_palettes_path(),_legacy_named_palettes_path()):
            try:payload=json.loads(path.read_text(encoding="utf-8"))
            except (OSError,ValueError,TypeError):continue
            entries=payload.get("palettes",[]) if isinstance(payload,dict) else payload
            if not isinstance(entries,list):continue
            palettes=[]
            for entry in entries:
                if not isinstance(entry,dict):continue
                name=str(entry.get("name","")).strip()[:64]; values=entry.get("colors",[])
                colors=[sanitize_hex(value,"") for value in values if isinstance(value,str)] if isinstance(values,list) else []; colors=[color for color in colors if color]
                if name and colors:palettes.append({"name":name,"colors":colors})
            return palettes
        return []
    def _save_saved_palettes(self):
        try:
            path=_saved_palettes_path(); path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps({"palettes":self.saved_palettes},indent=2),encoding="utf-8")
        except OSError:pass
    def save_saved_palette(self,*_args):
        if not self.saved:return
        dialog=Gtk.Dialog(title="Save Palette",parent=self,flags=Gtk.DialogFlags.MODAL); dialog.add_buttons("Cancel",Gtk.ResponseType.CANCEL,"Save",Gtk.ResponseType.OK); dialog.set_default_response(Gtk.ResponseType.OK)
        content=dialog.get_content_area(); content.set_spacing(8); content.set_border_width(12); prompt=Gtk.Label(label="Name this palette built from Saved Swatches:"); prompt.set_xalign(0); content.pack_start(prompt,False,False,0); entry=Gtk.Entry(); entry.set_placeholder_text("Palette name"); entry.set_max_length(64); entry.set_activates_default(True); content.pack_start(entry,False,False,0)
        save_button=dialog.get_widget_for_response(Gtk.ResponseType.OK); save_button.set_sensitive(False); entry.connect("changed",lambda field:save_button.set_sensitive(bool(field.get_text().strip()))); dialog.show_all(); response=dialog.run(); name=entry.get_text().strip()[:64]
        if response==Gtk.ResponseType.OK and name:
            palette={"name":name,"colors":list(self.saved)}; existing=next((index for index,item in enumerate(self.saved_palettes) if item["name"].casefold()==name.casefold()),None)
            if existing is None:self.saved_palettes.append(palette)
            else:self.saved_palettes[existing]=palette
            self._save_saved_palettes(); self.saved_palette.refresh_palettes(); self.saved_palette.set_active(existing if existing is not None else len(self.saved_palettes)-1)
        dialog.destroy()
    def delete_saved_palette(self,index):
        if index<0 or index>=len(self.saved_palettes):return
        palette=self.saved_palettes[index]; dialog=Gtk.MessageDialog(transient_for=self,flags=Gtk.DialogFlags.MODAL,message_type=Gtk.MessageType.QUESTION,buttons=Gtk.ButtonsType.NONE,text=f"Delete ‘{palette['name']}’?")
        dialog.format_secondary_text("This removes it from Saved Palettes. Colors already loaded into Current Palette will remain there."); dialog.add_buttons("Cancel",Gtk.ResponseType.CANCEL,"Delete",Gtk.ResponseType.OK); response=dialog.run(); dialog.destroy()
        if response!=Gtk.ResponseType.OK:return
        active=self.saved_palette.active_index; self.saved_palettes.pop(index); self._save_saved_palettes()
        if active==index:active=None
        elif active is not None and active>index:active-=1
        self.saved_palette.refresh_palettes(); self.saved_palette.set_active(active)
    def use_saved_palette_collection(self,index):
        if index<0 or index>=len(self.saved_palettes):return
        colors=list(self.saved_palettes[index]["colors"])
        if not colors:return
        self.clear_random_palette(); self.custom_palette=colors; self.custom_palette_template=list(colors); self.custom_palette_anchor=colors[0]
        if self.recipe_active():self.recipe.set_active_id("none")
        self.saved_palette.set_active(index); self.set_color(colors[0],preserve_custom=True); GLib.idle_add(self.expand_for_palette,len(colors))
    def _load_saved(self):
        for path in (_palette_path(),_legacy_palette_path()):
            try:return [sanitize_hex(c) for c in json.loads(path.read_text(encoding="utf-8")) if isinstance(c,str)]
            except (OSError,ValueError,TypeError):pass
        return []
    def _save_saved(self):
        try:_palette_path().write_text(json.dumps(self.saved,indent=2),encoding="utf-8")
        except OSError:pass
    def add_active(self,*_args):
        if self.color not in self.saved:self.saved.append(self.color);self._save_saved();self.render_saved()
    def save_generated(self,*_args):
        self.saved.extend(self.generated_colors()); self._save_saved(); self.render_saved()
    def move_saved(self,index,delta):
        target=max(0,min(len(self.saved)-1,index+delta))
        if target!=index:self.saved.insert(target,self.saved.pop(index));self._save_saved();self.render_saved()
    def remove_saved(self,index):self.saved.pop(index);self._save_saved();self.render_saved()
    def clear_saved(self,*_args):self.saved=[];self._save_saved();self.render_saved()
    def _saved_swatch_icon(self,icon,tooltip,handler,size,opacity):
        event=Gtk.EventBox(); event.set_visible_window(False); event.set_size_request(size,size); event.add(_svg_image(icon,max(9,size-4),"#000000")); event.set_opacity(opacity); event.set_tooltip_text(tooltip); event.connect("button-press-event",lambda *_args:handler()); return event
    def _saved_swatch_hover(self,_widget,event,arrows,visible):
        if not visible and getattr(event,"detail",None)==Gdk.NotifyType.INFERIOR:return False
        arrows.set_sensitive(visible); arrows.set_opacity(.5 if visible else 0); return False
    def _saved_swatch_widget(self,color,index):
        outer=Gtk.EventBox(); outer.set_hexpand(True); outer.set_size_request(74,34); outer.add_events(Gdk.EventMask.ENTER_NOTIFY_MASK|Gdk.EventMask.LEAVE_NOTIFY_MASK); overlay=Gtk.Overlay(); target=Gtk.EventBox(); area=Gtk.DrawingArea(); area.set_size_request(74,34); area.set_hexpand(True); rgba=_rgba(color)
        area.connect("draw",lambda widget,cr:(cr.set_source_rgba(rgba.red,rgba.green,rgba.blue,1),cr.rectangle(0,0,widget.get_allocated_width(),widget.get_allocated_height()),cr.fill(),False)[-1]); target.add(area); target.connect("button-press-event",lambda *_args:self.set_color(color)); overlay.add(target)
        label=Gtk.Label(); label.set_markup(f"<span foreground='#000000'>{color}</span>"); label.set_halign(Gtk.Align.CENTER); label.set_valign(Gtk.Align.CENTER); label.set_opacity(.6); overlay.add_overlay(label)
        remove=self._saved_swatch_icon("close",f"Remove {color}",lambda:self.remove_saved(index),14,.6); remove.set_halign(Gtk.Align.END); remove.set_valign(Gtk.Align.START); remove.set_margin_end(1); remove.set_margin_top(1); overlay.add_overlay(remove)
        arrows=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=0); arrows.set_hexpand(True); arrows.set_halign(Gtk.Align.FILL); arrows.set_valign(Gtk.Align.CENTER); arrows.set_sensitive(False); arrows.set_opacity(0); arrows.pack_start(self._saved_swatch_icon("left",f"Move {color} left",lambda:self.move_saved(index,-1),16,1),False,False,0); arrows.pack_end(self._saved_swatch_icon("right",f"Move {color} right",lambda:self.move_saved(index,1),16,1),False,False,0); overlay.add_overlay(arrows)
        outer.connect("enter-notify-event",self._saved_swatch_hover,arrows,True); outer.connect("leave-notify-event",self._saved_swatch_hover,arrows,False); outer.add(overlay); outer.set_tooltip_text(f"{color} - Hover to reorder; use × to remove"); return outer
    def render_saved(self):
        if not hasattr(self,"saved_box"):return
        for child in self.saved_box.get_children():self.saved_box.remove(child)
        if not self.saved:self.saved_box.add(Gtk.Label(label="No saved swatches yet"))
        for index,color in enumerate(self.saved):self.saved_box.add(self._saved_swatch_widget(color,index))
        self.saved_box.show_all()
    def import_palette(self,*_args):
        chooser=Gtk.FileChooserDialog(title="Import colors into Saved Swatches",parent=self,action=Gtk.FileChooserAction.OPEN,buttons=("Cancel",Gtk.ResponseType.CANCEL,"Import",Gtk.ResponseType.OK)); file_filter=Gtk.FileFilter(); file_filter.set_name("Palette files (*.gpl, *.json)"); file_filter.add_pattern("*.gpl"); file_filter.add_pattern("*.json"); chooser.add_filter(file_filter)
        if chooser.run()==Gtk.ResponseType.OK:
            try:
                self.saved=palette_from_text(Path(chooser.get_filename()).read_text(encoding="utf-8")); self._save_saved();self.render_saved()
            except (OSError,ValueError,TypeError):pass
        chooser.destroy()
    def export_palette(self,*_args):
        if not self.saved:return
        chooser=Gtk.FileChooserDialog(title="Export Saved Swatches for Inkscape",parent=self,action=Gtk.FileChooserAction.SAVE,buttons=("Cancel",Gtk.ResponseType.CANCEL,"Export",Gtk.ResponseType.OK)); chooser.set_current_name("HuePrint-Saved-Swatches.gpl"); chooser.set_do_overwrite_confirmation(True); file_filter=Gtk.FileFilter(); file_filter.set_name("GIMP Palette (*.gpl)"); file_filter.add_pattern("*.gpl"); chooser.add_filter(file_filter)
        if chooser.run()==Gtk.ResponseType.OK:
            try:Path(chooser.get_filename()).write_text(palette_to_gpl(self.saved,"HuePrint Saved Swatches"),encoding="utf-8")
            except OSError:pass
        chooser.destroy()
