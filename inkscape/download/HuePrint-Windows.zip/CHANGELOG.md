# Changelog

## 1.1.5 — 2026-07-25

- Replaced the broken GTK root-window picker on Windows with native virtual-screen capture, including HiDPI and multi-monitor coordinate scaling.
- Moved Apply beside independent Fill, Stroke, and Create swatches on canvas options while enforcing at least one selected action.
- Rebuilt Harmony as a visual chooser with generated color previews, names, descriptions, and selected-state indicators.
- Restyled light-theme buttons and SVG icons with light surfaces and dark foregrounds.
- Increased the subtitle text size and adopted the official color wheel terminology.
- Synchronized the HTML palette recipe names with the extension and grouped all recipes by their current categories.

## 1.1.4 — 2026-07-18

- Prepared a clean, versioned package for submission to the Inkscape Extensions Gallery.
- Added an extension-gallery icon, menu description, license, compatibility details, and reviewer metadata.
- Moved persistent saved-palette data out of Inkscape's configuration directory while preserving read-only migration from the legacy location.
- Declared support for Inkscape 1.4.x and confirmed operation with Inkscape 1.4.4 on Windows.


## 1.1.3 — 2026-07-18

- Made HuePrint and section titles black in light mode while retaining white titles in dark mode.
- Standardized every light-theme button on the same dark-gray surface with white text and SVG icons.
- Flipped the Use saved colors as current palette icon so its arrow points upward toward Swatches.

## 1.1.2 — 2026-07-17

- Made a screen-picker click close the overlay immediately and commit the sampled pixel as Active Color.
- Added Use saved colors as current palette, preserving the complete saved order for Apply and canvas swatches.
- Increased generated palettes from 8 to 16 swatches and allowed saved-derived current palettes to exceed that limit.
- Automatically widens the window for larger current palettes while keeping every swatch in the metadata table.
- Changed Saved Palette export to Inkscape-compatible GIMP Palette (GPL) files and added GPL/JSON import support.

## 1.1.1 — 2026-07-17

- Replaced GTK's implicit menu-button behavior with explicit, reliable popover controls for Harmony and Palette recipe.
- Restored pointer selection in both chooser popovers.
- Released the lightness slider's keyboard focus when a drag ends so it does not remain selected.

## 1.1.0 — 2026-07-17

- Expanded the palette catalog from 33 to 53 entries with Vibrant, Harmony, Dark & Luminous, and Temperature categories.
- Added advanced recipe transforms for exact base preservation, absolute/relative lightness, chroma floors and absolutes, and absolute/relative hue.
- Preserved all legacy recipe outputs across seven regression seed colors.
- Reworked Randomize into seeded, category-aware temporary palette state with bounded variation, validation, safe fallback, and undo/redo restoration.
- Removed Manual Palette from the Inkscape recipe chooser while retaining the internal `none` state for compatibility.
- Fixed lightness slider dragging and retained the live active-color gradient.
- Replaced the picker glyph with a clearer SVG eyedropper.
- Rebuilt the screen picker as a position-stable frozen desktop overlay with a blue frame, mode notice, live color swatch, and HEX/RGB/HSL metadata tile.
- Kept Escape scoped to canceling the picker and returning to HuePrint.

## 1.0.0 — 2026-07-17

- Released the first complete HuePrint Inkscape extension with the interactive color donut, harmony geometry, recipe browser, metadata table, saved palettes, import/export, screen color picking, theme support, and click-to-run Windows installer.